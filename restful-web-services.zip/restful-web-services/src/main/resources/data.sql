insert into user values(1, sysdate(), 'AB');
insert into user values(2, sysdate(), 'Jaam');
insert into user values(3, sysdate(), 'Jill');