package com.in28minutes.res.webservices.restfulwebservices.exception;

import java.util.Date;

public class ExceptionResponse {
	
	private Date timestamp;
	private String msg;
	private String detailMsg;
	
	public ExceptionResponse(Date timestamp, String msg, String detailMsg) {
		super();
		this.timestamp = timestamp;
		this.msg = msg;
		this.detailMsg = detailMsg;
		
	}
	
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getDetailMsg() {
		return detailMsg;
	}
	public void setDetailMsg(String detailMsg) {
		this.detailMsg = detailMsg;
	}
	

}
