package com.in28minutes.res.webservices.restfulwebservices.user;

import org.hibernate.engine.spi.ExtendedSelfDirtinessTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

}
